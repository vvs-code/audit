<?php

    require_once $_SERVER['DOCUMENT_ROOT'].'/functions.php';

    unset($_SESSION['user']);
    leave();
